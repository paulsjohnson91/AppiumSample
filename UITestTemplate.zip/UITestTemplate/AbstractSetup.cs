﻿using System;
using NUnit.Framework;
using Xamarin.UITest;
using Xamarin.UITest.Android;
using Xamarin.UITest.iOS;
using System.Linq;
using System.Collections.Generic;


namespace UITest
{
    [TestFixture(Platform.Android)]
    [TestFixture(Platform.iOS)]
    public abstract class AbstractSetup
    {
        protected IApp app;
        protected Platform platform;

        protected bool OnAndroid { get; set; }
        protected bool OniOS { get; set; }

        protected Dictionary<string, string[]> LoginDetails;

        public AbstractSetup(Platform platform)
        {
            this.platform = platform;
            LoginDetails =
                new Dictionary<string, string[]>();

            LoginDetails.Add("Valid_user", new String[] { "xamarintst@gmail.com", "Xamarin123" });
            LoginDetails.Add("Invalid_user", new String[] { "calabash@incorrect.com", "password" });
        }

        [SetUp]
        public virtual void BeforeEachTest()
        {
            app = AppInitializer.StartApp(platform);

            OnAndroid = app.GetType() == typeof(AndroidApp);
            OniOS = app.GetType() == typeof(iOSApp);
        }



 



    }
}
