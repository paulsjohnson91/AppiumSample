﻿using System;
using NUnit.Framework;
using Xamarin.UITest;

// Aliases Func<AppQuery, AppQuery> with Query
using Query = System.Func<Xamarin.UITest.Queries.AppQuery, Xamarin.UITest.Queries.AppQuery>;

namespace UITest
{
    public class PageTemplate : BasePage
    {
        readonly Query templateQuery;


        public PageTemplate()
            : base(x => x.Marked("marker1"), x => x.Marked("marker2"))
        {
            if (OnAndroid)
            {
                templateQuery = x => x.Marked("marker1");
            }

            if (OniOS)
            {
                templateQuery = x => x.Marked("marker1");
            }
        }



    }
}
